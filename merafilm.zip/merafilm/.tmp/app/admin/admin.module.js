'use strict';

angular.module('merafilmApp.admin', ['merafilmApp.auth', 'ngRoute']);
//# sourceMappingURL=admin.module.js.map
