'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(function () {
  var MoviesComponent = function () {
    function MoviesComponent($http, $scope, socket) {
      _classCallCheck(this, MoviesComponent);

      this.$http = $http;
      this.socket = socket;
      this.awesomeThings = [];

      $scope.$on('$destroy', function () {
        socket.unsyncUpdates('moviesendpoint');
      });
    }

    _createClass(MoviesComponent, [{
      key: '$onInit',
      value: function $onInit() {
        var _this = this;

        this.$http.get('/api/moviesendpoints').then(function (response) {
          _this.awesomeThings = response.data;
          _this.socket.syncUpdates('moviesendpoint', _this.awesomeThings);
        });
      }
    }, {
      key: 'addThing',
      value: function addThing() {
        if (this.mname && this.mdesc && this.mtime) {
          this.$http.post('/api/moviesendpoints ', {
            name: this.mname,
            description: this.mdesc,
            time: this.mtime
          });
          this.newThing = '';
        }
      }
    }, {
      key: 'deleteThing',
      value: function deleteThing(moviesendpoint) {
        this.$http.delete('/api/moviesendpoints/' + moviesendpoint._id);
      }
      //}

    }, {
      key: 'editThing',
      value: function editThing(thing) {
        console.log("this enter");
        console.log("i callled:f1");
        //$("tr").nextAll("input[type=text]").disabled=false;
        var container = document.getElementById(thing.name);

        // Find its child `input` elements
        var inputs = container.getElementsByTagName('input');
        for (var index = 0; index < inputs.length; ++index) {
          inputs[index].disabled = false;
        }
      }
    }, {
      key: 'updateThing',
      value: function updateThing(movie) {
        this.$http.put('/api/moviesendpoints/' + movie._id, JSON.stringify(movie));
      }
    }]);

    return MoviesComponent;
  }();

  angular.module('merafilmApp').component('movies', {
    templateUrl: 'app/movies/movies.html',
    controller: MoviesComponent
    //controllerAs: Movies
  });
})();
//# sourceMappingURL=movies.controller.js.map
