'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(function () {
  var OmdbiComponent = function () {
    function OmdbiComponent($http, $scope, socket) {
      _classCallCheck(this, OmdbiComponent);

      this.$http = $http;
      this.socket = socket;
      this.awesomeThings = [];

      $scope.$on('$destroy', function () {
        socket.unsyncUpdates('thing');
      });
    }

    _createClass(OmdbiComponent, [{
      key: '$onInit',
      value: function $onInit() {
        var _this = this;

        this.$http.get('http://www.omdbapi.com/?t=fan&y=2016&plot=short&r=json').then(function (response) {
          _this.awesomeThings = response.data;

          _this.socket.syncUpdates('thing', _this.awesomeThings);
        });
      }
    }, {
      key: 'addThing',
      value: function addThing() {
        if (this.details) {
          this.$http.post('/api/omdbiendpoints', {
            details: this.awesomeThings
          });
          //this.newThing = '';
        }
      }
    }]);

    return OmdbiComponent;
  }();

  angular.module('merafilmApp').component('omdbi', {
    templateUrl: 'app/omdbi/omdbi.html',
    controller: OmdbiComponent
  });
})();
//# sourceMappingURL=omdbi.controller.js.map
