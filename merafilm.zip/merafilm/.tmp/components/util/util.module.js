'use strict';

angular.module('merafilmApp.util', []);
//# sourceMappingURL=util.module.js.map
