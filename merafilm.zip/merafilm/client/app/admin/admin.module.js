'use strict';

angular.module('merafilmApp.admin', ['merafilmApp.auth', 'ngRoute']);
