'use strict';

angular.module('merafilmApp.util', []);
